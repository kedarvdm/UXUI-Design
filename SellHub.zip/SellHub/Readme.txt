Running the prototype
1) Install wampserver 2.5 with PHP and MySQL with PHPMyAdmin from http://www.wampserver.com/en/
2) Create "sellhub_schema" blank database.
3) Import "sellhub_schema.sql" to create schema and data for the prototype.
4) Copy Sellhub folder in wamp installation folder inside www directory.
5) Run the prototype using "http://localhost/sellhub/" OR "http://localhost:8888/sellhub/"